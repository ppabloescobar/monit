
# Stack Monitoring

Kod zawiera instalacje i konfiguracje komponentów należących do monitoringu takich jak grafana-server(prod/dev),dedykowane instancje prometheus-server na potrzeby aplikacji, tahnos-prod który odpowiada za centralizację metryk pobieranych przez koncowki prometheus-server.

## Struktura katalogowa:
```
alertmanager-server - centralny system notyfikacji
blackbox-exporter-prod - centralny system e2e
elasticsearch-exporter-prod - komponent odpowiedzialny za zbieranie dancyh o stanie klastra elasticsearch
grafana-server-prod - 
prometheus-server-aic
prometheus-server-bizon
prometheus-server-datastax
prometheus-server-default
prometheus-server-e2e
prometheus-server-elk
prometheus-server-jenkins
prometheus-server-kafka
prometheus-server-mon
prometheus-server-naps
prometheus-server-p360biznes
prometheus-server-peopay
prometheus-server-prod
prometheus-server-tedy
rook-ceph
thanos-prod
```
